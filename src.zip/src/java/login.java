
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author reddyjyoshnagurrala
 */
@ManagedBean
@SessionScoped
public class login implements Serializable {
    private String id;
    private String pwd;
    private user userAccount;
    private admin adminAccount;
    private String sec_ans1;
    private String sec_ans2;

    public admin getAdminAccount() {
        return adminAccount;
    }

    public void setAdminAccount(admin adminAccount) {
        this.adminAccount = adminAccount;
    }

    
    public user getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(user userAccunt) {
        this.userAccount = userAccunt;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getSec_ans1() {
        return sec_ans1;
    }

    public void setSec_ans1(String sec_ans1) {
        this.sec_ans1 = sec_ans1;
    }

    public String getSec_ans2() {
        return sec_ans2;
    }

    public void setSec_ans2(String sec_ans2) {
        this.sec_ans2 = sec_ans2;
    }

    
    
    public String login()
    {
        try{
            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            return "internalError";
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            rs=stat.executeQuery("Select * from t_user where t_username='"+id+"'");
            while(rs.next())
            {
                if(id.equals(rs.getString("t_username")))
                {
                    
                    if(pwd.equals(rs.getString("t_password")))
                    {
                        if(rs.getString("t_user_status").equals("approved"))
                        {
                           String role=rs.getString("t_role");

                            if(role.equals("admin"))
                            {
                                adminAccount=new admin(id,pwd,role);
                                return "admin";
                            }else if(role.equals("regular user"))
                            {
                                String tag=rs.getString("t_tag");
                                String email=rs.getString("t_email");
                                userAccount=new user(id,pwd,email, tag, role);
                                return "user";
                            }
                        }
                        else
                        {
                            return "regPending";
                        }
                    }
                    else
                    {
                        return "loginNotOk";
                    }
                }
                else
                {
                    return "usernotFound";
                }
            }
            return "usernotFound";
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return "internalError";
        }
         finally{
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }       
        
    }
     
    public String changeForgotPassword()
    {
        try{
            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            return "internalError";
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        ResultSet rs1=null;
        
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            rs=stat.executeQuery("Select * from t_user where t_username='"+id+"'");
            boolean userFound=false;
            String email="";
            String password="";
            while(rs.next())
            {
                userFound=true;
                 email=rs.getString("t_email");
                 password=rs.getString("t_password");
            }
            if(userFound)
            {
                String newPwd=id+"@123";
                String to=email;
                String from="grjyoshna@gmail.com";
                String host="localhost";
                
//                Properties properties=System.getProperties();
//                Session session=Session.getDefaultInstance(properties);
                         Properties props = new Properties();
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.host", "smtp.gmail.com");
                props.put("mail.smtp.port", "587");
                   //  Session session=Session.getDefaultInstance(props);
//                Session session = Session.getInstance(props,
//                  new javax.mail.Authenticator() {
//                    protected PasswordAuthentication getPasswordAuthentication() {
//                        return new PasswordAuthentication(id, newPwd);
//                    }
//                  });
                final String pwdAuth=password;
                    Session session = Session.getInstance(props,
                  new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(id, pwdAuth);
                    }
                  });
                try{
                    MimeMessage message=new MimeMessage(session);
                    message.setFrom(new InternetAddress(from));
                     // Set To: header field of the header.
                    message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

                    // Set Subject: header field
                message.setSubject("Reset Password..");
                
                rs1=stat.executeQuery("select * from t_user where t_username='"+id+"'");
               
                // Now set the actual message
                message.setText("This is your new password "+newPwd+" . Please login back and reset your password.");
                boolean pwdChanged=false;
                if(rs1.next())
                {
                   pwdChanged=true;
                    stat.executeUpdate("Update t_user set t_password='"+newPwd+"' where t_username='"+id+"'");
                }
                
                // Send message
                Transport.send(message);
                System.out.println("Sent message successfully....");
                return "forgotPwdOk";
                
                    
                }
                catch(MessagingException mex)
                {
                    
                    StringWriter stringWriter = new StringWriter();
                     mex.printStackTrace(new PrintWriter(stringWriter, true));
                    return "internalError";
                 
                    
                }
            }
            else
            {
                return "forgotPwdError";
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return "internalError";
        }
         finally{
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }       
    }
     
//     public String forgotPassword()
//    {
//        try{
//            
//             Class.forName("com.mysql.jdbc.Driver");
//
//        }catch(Exception e)
//        {
//            return "internalError";
//        }
//        Connection conn=null;
//        Statement stat=null;
//        ResultSet rs=null;
//        ResultSet rs1=null;
//        
//        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
//        try{
//            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
//            stat=conn.createStatement();
//            rs=stat.executeQuery("Select * from t_user where t_username='"+id+"'");
//            boolean userFound=false;
//            String email="";
//            String password="";
//            while(rs.next())
//            {
//                userFound=true;
//                 email=rs.getString("t_email");
//                 password=rs.getString("t_password");
//            }
//            if(userFound)
//            {
//                 String newPwd=id+"@123";
//                String to=email;
//                String from="grjyoshna@gmail.com";
//                String host="localhost";
//                
//                Properties props = new Properties();
//                props.put("mail.smtp.auth", "true");
//                props.put("mail.smtp.starttls.enable", "true");
//                props.put("mail.smtp.host", "smtp.gmail.com");
//                props.put("mail.smtp.port", "888");
//
//                final String pwdAuth=password;
//                    Session session = Session.getInstance(props,
//                  new javax.mail.Authenticator() {
//                    protected PasswordAuthentication getPasswordAuthentication() {
//                        return new PasswordAuthentication(id, pwdAuth);
//                    }
//                  });
//                
//                try{
//                    MimeMessage message=new MimeMessage(session);
//                    message.setFrom(new InternetAddress(from));
//                     // Set To: header field of the header.
//                    message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
//
//                    // Set Subject: header field
//                message.setSubject("Reset Password..");
//                
//                rs1=stat.executeQuery("select * from t_user where t_username='"+id+"'");
//               
//                // Now set the actual message
//                message.setText("This is your new password "+newPwd+" . Please login back and reset your password.");
//                boolean pwdChanged=false;
//                if(rs1.next())
//                {
//                   pwdChanged=true;
//                    stat.executeUpdate("Update t_user set t_password='"+newPwd+"' where t_username='"+id+"'");
//                }
//                
//                // Send message
//                Transport.send(message);
//                System.out.println("Sent message successfully....");
//                return "forgotPwdOk";
//                
//                    
//                }
//                catch(MessagingException mex)
//                {
//                    
//                    StringWriter stringWriter = new StringWriter();
//                     mex.printStackTrace(new PrintWriter(stringWriter, true));
//                    return "internalError";
//                 
//                    
//                }
//             }
//            else
//            {
//                return "forgotPwdError";
//            }
//        }
//        catch(SQLException e)
//        {
//            e.printStackTrace();
//            return "internalError";
//        }
//         finally{
//            try{
//                conn.close();
//                stat.close();
//                rs.close();
//            }
//            catch(Exception e)
//            {
//                e.printStackTrace();
//              return "internalError";
//            }
//        }       
//    }

    public String forgotPassword()
    {
        try{
            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            return("Internal Error");
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            rs=stat.executeQuery("Select * from t_user where t_username='"+id+"'");
            boolean userFound=false;
            while(rs.next())
            {
                if(id.equals(rs.getString("t_username")))
                {
                    userFound=true;
                    userAccount=new user(id);
                   
                }
                
            }
            if(userFound) return "forgotPassword";
            else return "usernotFound";
            
            }
        catch(SQLException e)
        {
            e.printStackTrace();
            return "internalError";
        }
         finally{
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }       
        
    }
     public String securityQuestion1()
    {
        try
            {           
             Class.forName("com.mysql.jdbc.Driver");
            }
            catch(Exception e)
            {
            return "internalError";
            }
            
            Connection conn=null;
            Statement stat=null;
            ResultSet rs=null;
            
            try{
                final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
                conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
                stat=conn.createStatement();
                rs=stat.executeQuery("select * from t_user where t_username='"+id+"'");
                boolean userFound=false;
                String q1="";
                while(rs.next())
                {
                    userFound=true;
                    q1=rs.getString("sec_qu_1");
                }
                
                if(userFound)
                { 
                    rs=stat.executeQuery("select * from security_questions where sq_id='"+q1+"'");
                    String qu1="";
                    while (rs.next())
                    {
                        qu1=rs.getString("sq");
                    }
                    return qu1;
                }
                else
                {
                    return "internalError";
                }
                }
            catch(SQLException e)
            {
                e.printStackTrace();
                return "internalError";
            }
            finally
            {
                try{
                    conn.close();
                    stat.close();
                    rs.close();
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                    return "internalError";
                }
            }
    }
    
     public String securityQuestion2()
    {
        try
            {           
             Class.forName("com.mysql.jdbc.Driver");
            }
            catch(Exception e)
            {
            return "internalError";
            }
            
            Connection conn=null;
            Statement stat=null;
            ResultSet rs=null;
            
            try{
                final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
                conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
                stat=conn.createStatement();
                rs=stat.executeQuery("select * from t_user where t_username='"+id+"'");
                boolean userFound=false;
                String q2="";
                while(rs.next())
                {
                    userFound=true;
                    q2=rs.getString("sec_qu_2");
                }
                if(userFound)
                {
                     rs=stat.executeQuery("select * from security_questions where sq_id='"+q2+"'");
                    String qu2="";
                    while (rs.next())
                    {
                        qu2=rs.getString("sq");
                    }
                    return qu2;
                }
                else
                {
                    return "internalError";
                }
                }
            catch(SQLException e)
            {
                e.printStackTrace();
                return "internalError";
            }
            finally
            {
                try{
                    conn.close();
                    stat.close();
                    rs.close();
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                    return "internalError";
                }
            }
    }
      public String verifySecurityQuestions(){
      try
            {           
             Class.forName("com.mysql.jdbc.Driver");
            }
            catch(Exception e)
            {
            return "internalError";
            }
            
            Connection conn=null;
            Statement stat=null;
            ResultSet rs=null;
            
            
            try{
                final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
                conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
                stat=conn.createStatement();
                rs=stat.executeQuery("select * from t_user where t_username='"+id+"'");
                while(rs.next())
                {
                    if(sec_ans1.equals(rs.getString("sec_ans1")))
                    {
                        if(rs.getString("sec_ans2").equals(sec_ans2))
                        {
                            return "resetPassword";
                        }
                        else
                        {
                            return "wrongAns";
                        }
                    }
                    else
                    {
                        return "wrongAns";
                    }
                    
                }
                return "internalError";
                }
            catch(SQLException e)
            {
                e.printStackTrace();
                return "internalError";
            }
            finally
            {
                try{
                    conn.close();
                    stat.close();
                    rs.close();
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                    return "internalError";
                }
            }
    }
    
    
}
