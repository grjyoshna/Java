
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author reddyjyoshnagurrala
 */
@ManagedBean
@SessionScoped
public class admin {
    private String user;
    private String pwd;
    private String role;
    private String email;
    public admin()
    {
        
    }
    public admin(String user,String pwd,String role)
    {
        this.user=user;
        this.pwd=pwd;
        this.role=role;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    
    public ArrayList<user> displayPendingUsers()
    {
        try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        ArrayList<user> displayUsers=new ArrayList<user>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_user where t_user_status='pending'");
            
            while(rs.next())
            {
              displayUsers.add(new user(rs.getString("t_username"),rs.getString("t_email")));
                
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return displayUsers;
    }
    
    public void approveUsers(String pendingUser)
    {
        try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        ArrayList<user> displayUsers=new ArrayList<user>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_user where t_username='"+pendingUser+"' ");
            while(rs.next())
            {
            stat.executeUpdate("Update t_user set t_user_status='approved' where t_username='"+pendingUser+"'");
            }
            //Display remaining users after approval
             
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        

    }
    
    public ArrayList<attractions> displayPendingAttractions()
    {
        try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        ArrayList<attractions> displayAttractions=new ArrayList<attractions>();
        final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;  
        Statement stat1=null;
        Statement stat2=null;//execution of a statement
        ResultSet rs = null; 
        ResultSet rs1=null;//set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_requests where status='pending'");
            while(rs.next())
            {
                String id=rs.getString("request_id");
                String user=rs.getString("r_user");
                String attraction=rs.getString("r_attraction");
                String tag=rs.getString("r_tag");
                String desc=rs.getString("r_desc");
                String city=rs.getString("r_city");
                String state=rs.getString("r_state");
                String country=rs.getString("r_country");
                String byUser=rs.getString("r_user");
                displayAttractions.add(new attractions(id,attraction,tag,desc,city,state,country,byUser));
            }
                  
         }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return displayAttractions;
    }
    
    public void approvePendingAttractions(String attractionName)
    {
        try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        ArrayList<user> displayUsers=new ArrayList<user>();
        final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;  
        Statement stat1=null;
        Statement stat2=null;//execution of a statement
        ResultSet rs = null; 
        ResultSet rs1=null;//set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_requests where r_attraction='"+attractionName+"'");
            boolean attractionFound=false;
            String att_name="";
            String att_desc="";
            String att_tag="";
            String att_city="";
            String att_State="";
            String att_Country="";
            while(rs.next())
            {
                attractionFound=true;
                 att_name=rs.getString(3);
                att_desc=rs.getString(5);
                 att_tag=rs.getString(4);
                att_city=rs.getString(6);
                 att_State=rs.getString(7);
                att_Country=rs.getString(8);
                
            }
            if(attractionFound)
            {
                stat.executeUpdate("Update t_requests set status='approved' where r_attraction='"+attractionName+"'");
                
                rs=stat.executeQuery("select * from t_attraction_id ");
                  int num=0;
                    while(rs.next())
                    {
                        num=rs.getInt(1);
                    }
                    num++;
                    stat.executeUpdate("Update t_attraction_id set next = '"+num+"'");
                    String att_id="A"+num;
                    
                    stat.executeUpdate("Insert into t_attraction values('"+att_id+"','"+att_name+"','"+att_tag+"','"+att_desc+"','"+att_city+"','"+att_State+"','"+att_Country+"','"+"0"+"')");
                    
            }
            
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
    }
    
}
