/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tulsi
 */

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.convert.Converter;


@ManagedBean(name = "searchtag", eager = true)
@SessionScoped
public class searchtag implements Serializable {
   //private static final long serialVersionUID = 1L;
  // public String tag = "1";
public String tag = "";


   private String attraction;
   private String city;

    public String getAttraction() {
        return attraction;
    }

    public void setAttraction(String attraction) {
        this.attraction = attraction;
    }
   
   public String getTag() {
      return tag;
   }

   public void setTag(String tag) {
      this.tag = tag;
   }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
   
   
   
   public void donothing()
   {
       
   }

public ArrayList<attractions> searchAttDisplay()
    
    {
         try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        ArrayList<attractions> displayatt=new ArrayList<attractions>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_attraction where attraction like'%" +tag + "%' or tag like '%"+tag+"%' or city like '%"+tag+"%' order by score");
            
            while(rs.next())
            {
              
               displayatt.add(new attractions(rs.getString("attraction"),rs.getString("desc"),rs.getString("tag"),
                      rs.getString("city"),
              rs.getString("state"),rs.getString("country"),rs.getString("score")));
             
                
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return displayatt;
    }

public ArrayList<attractions> searchAtt1Display()
    
    {
         try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        ArrayList<attractions> displayatt=new ArrayList<attractions>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_attraction where attraction like'%" +tag + "%' order by score");
            
            while(rs.next())
            {
              displayatt.add(new attractions(rs.getString("attraction"),rs.getString("desc"),rs.getString("tag"),
                      rs.getString("city"),
              rs.getString("state"),rs.getString("country"),rs.getString("score")));
             
              
              
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return displayatt;
    }




 public ArrayList<attractions> displayAttractions()
       

    {
        try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        ArrayList display =new ArrayList<attractions>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   
        ResultSet rs1= null;
//set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_requests  ");
           
            
            
            
            if(rs.next())
            {
              display.add(new attractions(rs.getString("attraction"),rs.getString("desc"),
              rs.getString("tag"),rs.getString("city"),
              rs.getString("state"),rs.getString("country"),rs.getString("score")));
                  
            }
             
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
                rs1.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        
  return display;
    }
 
 
 public ArrayList<attractions> finalAttractions()
       

    {
        try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        ArrayList display =new ArrayList<attractions>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   
        ResultSet rs1= null;
//set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_requests where city = '"+ tag +"' ");
           
            
            
            
            if(rs.next())
            {
              display.add(new attractions(rs.getString("attraction"),rs.getString("desc"),
              rs.getString("tag"),rs.getString("city"),
              rs.getString("state"),rs.getString("country"),rs.getString("score")));
                  
            }
             
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
                rs1.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        
  return display;
    }

public ArrayList<attractions> viewAttDisplay()
    
    {
         try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        ArrayList<attractions> displayatt=new ArrayList<attractions>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_attraction ");
            
            while(rs.next())
            {
             
              
              displayatt.add(new attractions(rs.getString("attraction"),rs.getString("desc"),
              rs.getString("tag"),rs.getString("city"),
              rs.getString("state"),rs.getString("country"),rs.getString("score")));
                  
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return displayatt;
    }
 
 
public ArrayList<attractions> Displayall()
    
    {
         try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        ArrayList<attractions> displayatt=new ArrayList<attractions>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_attraction ");
            
            while(rs.next())
            {
             
              
              displayatt.add(new attractions(rs.getString("attraction"),rs.getString("desc"),
              rs.getString("tag"),rs.getString("city"),
              rs.getString("state"),rs.getString("country"),rs.getString("score")));
                  
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return displayatt;
    }
 
    public String Displaydisplay(String attr)
           
    
    {
         String result = "hello";
         try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
      //  ArrayList<attractions> displayatt=new ArrayList<attractions>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_attraction where attraction = '" + attraction + "' ");
            
            if(rs.next())
            {
             
             result = rs.getString("attraction") + rs.getString("desc") + rs.getString("tag") +
               rs.getString("city") + rs.getString("state")+  rs.getString("country") ;     
                
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return result;
    }
     
     public ArrayList<attractions> displayAttraction_fav()              
    {
        
         try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
       ArrayList<attractions> displayatt=new ArrayList<attractions>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_attraction where attraction = '" + attraction + "' ");
            
            if(rs.next())
            {
             displayatt.add(new attractions(rs.getString("attraction"),rs.getString("desc"),rs.getString("tag"),rs.getString("city"),rs.getString("state"), rs.getString("country"),rs.getString("score")));
            
                
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return displayatt;
    }
     
     public String dis_fav_att(String att)
     {
         attraction=att;
         return "displayAttraction";
     }
     
     public String dis_fav_city(String destination)
     {
         city=destination;
         return "displayFavoriteDestination";
     }
     
     public ArrayList<attractions> displayAttraction_fav_city()              
    {
        
         try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
       ArrayList<attractions> displayatt=new ArrayList<attractions>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from t_attraction where city='"+city+"'");
            
            if(rs.next())
            {
             displayatt.add(new attractions(rs.getString("attraction"),rs.getString("desc"),rs.getString("tag"),rs.getString("city"),rs.getString("state"), rs.getString("country"),rs.getString("score")));
            
                
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return displayatt;
    }
      public String view_attPage(String name)
    {
        tag=name;
            return "search";
    }
}  
    