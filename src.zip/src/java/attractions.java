
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author reddyjyoshnagurrala
 */
@ManagedBean
@SessionScoped
public class attractions {
    private String attraction_id;
    private String attrName;
    
    private String attrTag;
    private String[] attrTagArray;
    private String attrDescription;
    private String attrCity;
    private String attrState;
    private String attrZipcode;
    
    private String attrCountry;
  private  String attrByUser;
    private String score;

    public String getAttrByUser() {
        return attrByUser;
    }

    public void setAttrByUser(String attrByUser) {
        this.attrByUser = attrByUser;
    }

    public String[] getAttrTagArray() {
        return attrTagArray;
    }

    public void setAttrTagArray(String[] attrTagArray) {
        this.attrTagArray = attrTagArray;
    }
    
    
    public attractions()
    {
        
    }
     public attractions(String a_id, String a_Name, String a_City, String a_Score) {
        attraction_id = a_id;
        attrName = a_Name;

        attrCity = a_City;

        score = a_Score;
    }

    public attractions(String id, String name, String tag, String desc, String city,String state,  String country,String user)
    {
        attraction_id=id;
        attrName=name;
        attrTag=tag;
        attrDescription=desc;
        attrCity=city;
        attrState=state;
     
        attrCountry=country;
        attrByUser=user;
    }
    public attractions(String name,  String desc, String tag,String city,String state,  String country,String score)
    {
       
        attrName=name;
        attrTag=tag;
        attrDescription=desc;
        attrCity=city;
        attrState=state;
     
        attrCountry=country;
        this.score=score;
    }
    public attractions(String name)
    {
       attrName=name;
    }
    
    public String getAttraction_id() {
        return attraction_id;
    }

    public void setAttraction_id(String attraction_id) {
        this.attraction_id = attraction_id;
    }

    public String getAttrName() {
        return attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public String getAttrTag() {
        return attrTag;
    }

    public void setAttrTag(String attrTag) {
        this.attrTag = attrTag;
    }

    public String getAttrDescription() {
        return attrDescription;
    }

    public void setAttrDescription(String attrDescription) {
        this.attrDescription = attrDescription;
    }

    public String getAttrCity() {
        return attrCity;
    }

    public void setAttrCity(String attrCity) {
        this.attrCity = attrCity;
    }

    public String getAttrState() {
        return attrState;
    }

    public void setAttrState(String attrState) {
        this.attrState = attrState;
    }

    public String getAttrZipcode() {
        return attrZipcode;
    }

    public void setAttrZipcode(String attrZipcode) {
        this.attrZipcode = attrZipcode;
    }

    public String getAttrCountry() {
        return attrCountry;
    }

    public void setAttrCountry(String attrCountry) {
        this.attrCountry = attrCountry;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
    
    public ArrayList<answers> displayQuestionAnswer(){
        try
            {           
             Class.forName("com.mysql.jdbc.Driver");
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
            
            Connection conn=null;
            Statement stat=null;
            ResultSet rs=null;
           // String username=getSessionData().getId();
           ArrayList<answers> ansList=new ArrayList<answers>();
           
            try{
                final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
                conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
                stat=conn.createStatement();
                
                    rs=stat.executeQuery("select * from question_answer where attraction_name='"+attrName+"' and status='read'");
                    while(rs.next())
                    {
                        ansList.add(new answers(rs.getString("question"),rs.getString("answer")));
                    }
                    
                 }
            catch(SQLException e)
            {
                e.printStackTrace();
              
            }
            finally
            {
                try{
                    conn.close();
                    stat.close();
                    rs.close();
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                   
                }
            }
            return ansList;
            
    }
   
    public String qu_ans_listPage(String name){
        
            attrName=name;
            return "qu_ans_list";
        }
    //Add Attraction
    public String addAttraction(String id)
    {
         try
        {
             
            Class.forName("com.mysql.jdbc.Driver");
            
        }
        catch (Exception e)
        {
           // ("Internal Error1! Please try again later.");
            e.printStackTrace();
            
        }
        
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
       
       
        try{
            
            final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            
            rs=stat.executeQuery("select * from t_request_id");
                   int next_request_id=0;
                   while(rs.next())
                   {
                       next_request_id=rs.getInt(1);
                       next_request_id+=1;
                   }
                  
                        String tags="";
                        for(String a: attrTagArray)
                        {
                            tags+=a+", ";
                        }
                        
                          
                   
                   int t = stat.executeUpdate("Update t_request_id set next = '" + next_request_id + "'");
                   
                   
                 rs=stat.executeQuery("select r_attraction from t_requests where r_attraction = '" + attrName + "'");
                
                  if(rs.next())
                  {
                      return ("already exists");
 
                  }
                  
                  else
                   
                  {  
                   // String idsample =this.id;
                    login log = new login();
                    user usr = new user();
                   String userId = log.getId();
                   // userId = usr.getEmail();
   
                   int r=stat.executeUpdate("insert into t_requests values ('"+next_request_id +"','" + id + "','" +attrName+"','"+tags+"',"
                   +"'"+attrDescription+"','"+attrCity+"','"+attrState+"','"+attrCountry+"','"+"pending"+"')");
                  
                  return ("Attraction created");
                  }

        }
        catch(SQLException e)
        {
                 e.printStackTrace();
                 System.out.println("error");
                return ("Internal Error2! Please try again later.");
             
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                
                rs.close();
                
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
       
    }
}
