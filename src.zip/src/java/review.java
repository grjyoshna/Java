
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
    public class review
    {

   private String atrName;
   private String atrReview;
   private String score;
   private String reviewBy;
   private login sessionData;

    public String getReviewBy() {
        return reviewBy;
    }

    public void setReviewBy(String reviewBy) {
        this.reviewBy = reviewBy;
    }

    public String getAtrName() {
        return atrName;
    }

    public void setAtrName(String atrName) {
        this.atrName = atrName;
    }

    public String getAtrReview() {
        return atrReview;
    }

    public void setAtrReview(String atrReview) {
        this.atrReview = atrReview;
    }

    public login getSessionData() {
        return sessionData;
    }

    public void setSessionData(login sessionData) {
        this.sessionData = sessionData;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
    
   public review(){
       
   }
   public review(String reviewBy, String name, String review)
   {
       this.reviewBy=reviewBy;
       atrName=name;
       atrReview=review;
   }
   
    
//     public ArrayList<attraction> displayAttractionsForReviews()
//    {
//        try{            
//             Class.forName("com.mysql.jdbc.Driver");
//
//        }catch(Exception e)
//        {
//            e.printStackTrace();
//            
//        }
//        Connection conn=null;
//        Statement stat=null;
//        ResultSet rs=null;
//        ArrayList<attraction> att=new ArrayList<attraction>();
//        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
//        try{
//            
//            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
//            stat=conn.createStatement();
//            rs=stat.executeQuery("select * from t_attraction");
//            while(rs.next())
//            {
//                att.add(new attraction(rs.getString("attraction")));
//            }
//            
//         }
//        catch(SQLException e)
//        {
//                    e.printStackTrace();
//                    
//        }
//        finally
//        {
//            try{
//                conn.close();
//                stat.close();
//                rs.close();
//            }
//            catch(Exception e)
//            {
//                e.printStackTrace();
//            }
//        }
//        return att;
//    }
//     
   public ArrayList<attractions> displayAttractionsForReviews()
    {
        try{            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            e.printStackTrace();
            
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        ArrayList<attractions> att=new ArrayList<attractions>();
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            rs=stat.executeQuery("select * from t_attraction");
            while(rs.next())
            {
                att.add(new attractions(rs.getString("attraction")));
            }
            
         }
        catch(SQLException e)
        {
                    e.printStackTrace();
                    
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return att;
    }
    public String addReview(String user){
        try{            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            e.printStackTrace();
            return "internalError";
            
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        
        
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            stat.executeUpdate("Insert into reviews values('"+user+"','"+atrName+"', '"+atrReview+"')");
            return "reviewAdded";
             }
        catch(SQLException e)
        {
                    e.printStackTrace();
                    return "internalError";
                    
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

        }
    }
    
    public String reviewPage(String att)
    {
        atrName=att;
        return "enterReview";
    }
    
    public String scorePage(String att)
    {
       atrName=att;
       return "enterScore";
    }
     public String addScore(String user){
        try{            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            e.printStackTrace();
            return "internalError";
            
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        
        
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
       
            rs=stat.executeQuery("select * from scores where attraction_name='"+atrName+"'");
            double calScore=0;
            double count=0; 
            while(rs.next())
            {
                count++;
                String sco=rs.getString("score");
                double sc=Double.parseDouble(sco);
                calScore+=sc;
            }
            
            double scoreUpd=Double.parseDouble(score);
            double attScore=0;
            if(count>0)
            {
             attScore=(calScore+scoreUpd)/count;
            }
            else
            {
               attScore=scoreUpd;
            }
           
            String attScoreString=Double.toString(attScore);
            stat.executeUpdate("Update t_attraction set score='"+attScoreString+"' where attraction='"+atrName+"'");
            stat.executeUpdate("Insert into scores values('"+user+"', '"+atrName+"','"+score+"')");
            return "scoreadded";
             }
        catch(SQLException e)
        {
                e.printStackTrace();
                return "internalError";                   
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

        }
    }
    
     public String dis_rev_page(String name)
     {
         atrName=name;
         return "displayReviews";
     }
     
     public ArrayList<review> displayReviews()
     {
         try{            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            e.printStackTrace();
            
            
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        ArrayList<review> reviews=new ArrayList<review>();
        
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            rs=stat.executeQuery("select * from reviews where attraction_name='"+atrName+"'");
            while(rs.next())
            {
                reviews.add(new review(rs.getString("user_id"),rs.getString("attraction_name"),rs.getString("review")));
            }
             }
        catch(SQLException e)
        {
                e.printStackTrace();
                                  
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

        }
        return reviews;
     }
                    
}
