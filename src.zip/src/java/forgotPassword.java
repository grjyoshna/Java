
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author reddyjyoshnagurrala
 */
@ManagedBean
@SessionScoped
public class forgotPassword implements Serializable{
    private String user;
    private user userAccount;
    private String sec_qu1;
    private String sec_qu2;
    private String sec_ans1;
    private String sec_ans2;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getSec_qu1() {
        return sec_qu1;
    }

    public void setSec_qu1(String sec_qu1) {
        this.sec_qu1 = sec_qu1;
    }

    public String getSec_qu2() {
        return sec_qu2;
    }

    public void setSec_qu2(String sec_qu2) {
        this.sec_qu2 = sec_qu2;
    }

    public String getSec_ans1() {
        return sec_ans1;
    }

    public void setSec_ans1(String sec_ans1) {
        this.sec_ans1 = sec_ans1;
    }

    public String getSec_ans2() {
        return sec_ans2;
    }

    public void setSec_ans2(String sec_ans2) {
        this.sec_ans2 = sec_ans2;
    }

    public user getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(user userAccount) {
        this.userAccount = userAccount;
    }
    
    
}
