
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author reddyjyoshnagurrala
 */
@ManagedBean
@RequestScoped
public class register {
    private String user_ID;
    private String pwd;
    private String email;
    private String[] tag;
    private String role;
    private String sq1;
    private String sq2;
    private String sa1;
    private String sa2;
   
   //public String[] userTags = {"1","2","3"};

    public String getSq1() {
        return sq1;
    }

    public void setSq1(String sq1) {
        this.sq1 = sq1;
    }

    public String getSq2() {
        return sq2;
    }

    public void setSq2(String sq2) {
        this.sq2 = sq2;
    }

    public String getSa1() {
        return sa1;
    }

    public void setSa1(String sa1) {
        this.sa1 = sa1;
    }

    public String getSa2() {
        return sa2;
    }

    public void setSa2(String sa2) {
        this.sa2 = sa2;
    }
 
 


    public String getUser_ID() {
        return user_ID;
    }

    public void setUser_ID(String user_ID) {
        this.user_ID = user_ID;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String[] getTag() {
        return tag;
    }

    public void setTag(String[] tag) {
       
        this.tag = tag;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    
    public String register()
    {
        //load the driver
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            
        }
        catch (Exception e)
        {
            return ("Internal Error1! Please try again later.");
        }
         Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        
        try
        {
            final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
            
            //connect to the database with user name and password
            connection = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            statement = connection.createStatement();
            //to search an onlineaccount based on id or ssn
            resultSet = statement.executeQuery("Select * from t_user "
                    + "where t_username = '" +user_ID+ "'" );
            
            if(resultSet.next())
            {
                 return("You have registered already");
            }
            else
            {
                if(validateUsername(user_ID) && validatePassword(pwd))
                {
                        resultSet=statement.executeQuery("select * from t_user_id");
                        int next=0;
                        while (resultSet.next())
                        {
                         next=resultSet.getInt(1);
                        }
                        next++;
                        String nextID="T"+next;
                        String userTags="";
                        
                        for(String a: tag)
                        {
                            userTags+=a+", ";
                        }
                          statement.executeUpdate("Update t_user_id set next_id='"+next+"'");
                       statement.executeUpdate("insert into t_user values('"+nextID+"', '"+user_ID+"','"+pwd+"','"+email+"','"+"regular user"+"', '"+"pending"+"', '"+userTags+"','"+sq1+"','"+sq2+"','"+sa1+"','"+sa2+"')");

                        return ("Registration Successful! Please "
                                 + "return to login your account.");
                
                }
                else if(!validateUsername(user_ID))
                {
                    return("Username is not valid. It should be between 3-10 characters and contains atleast one letter and one digit. ");
                }
                else 
                {
                     return("Password is not valid. Please try again..");
                }
            }   
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return ("Internal Error2! Please try again later.");
             
        }
        finally
        {
            try
            {
                resultSet.close();
                statement.close();
                connection.close();
                
            }
            catch (Exception e)
            {
                 
                e.printStackTrace();
            }
        }
    
    }
    
    public boolean validateUsername(String user)
    {
        return user.matches("(?=.*[a-zA-Z])(?=.*\\d).{3,10}");
    }
      public  boolean validatePassword(String pwd) 
    {
        return pwd.matches("(?=.*[a-zA-Z])(?=.*\\d)(?=.*[!@#$%&*()_+=|<>?{}\\\\[\\\\]~-]).{5,10}");
    }
}
