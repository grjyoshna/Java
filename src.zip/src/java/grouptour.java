/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tulsi
 */

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.convert.Converter;


@ManagedBean(name = "grouptour", eager = true)
@SessionScoped
public class grouptour implements Serializable {

public String info = "";


   private String deal;

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getDeal() {
        return deal;
    }

    public void setDeal(String deal) {
        this.deal = deal;
    }

       
   public void donothing()
   {
       
   }

  public ArrayList<tourdetails> display()
    
    {
         try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
         
         
         
        ArrayList<tourdetails> display=new ArrayList<tourdetails>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from tour_package where members = '" + info + "' or  price = '"+ info +"' or days = '" +info +"' ");
          
            while(rs.next())
            {
             
              display.add(new tourdetails(rs.getString("packagename"),rs.getString("members"),rs.getString("price"),
                      rs.getString("days")));

                             
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return display;
    }


    
}
    


    
    
    
    
    

