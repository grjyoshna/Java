
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author reddyjyoshnagurrala
 */
@ManagedBean
@SessionScoped
public class user {
    @ManagedProperty(value="#{login}")
    
    private login sessionData;
    private String user;
    private String pwd;
    private String email;
    private String tag;
    private String[] tagArray;
    private String role;
    //used for reset password
    private String sec_qu1;
    private String sec_qu2;
    private String sec_ans1;
    private String sec_ans2;
    private String oldPwd;

   
    private String newPwd1;
    private String newPwd2;
    private String ans;
    private String q_id;
    private String atrName;
  
    public String getNewPwd1() {
        return newPwd1;
    }

    public void setNewPwd1(String newPwd1) {
        this.newPwd1 = newPwd1;
    }

    public String getNewPwd2() {
        return newPwd2;
    }

    public void setNewPwd2(String newPwd2) {
        this.newPwd2 = newPwd2;
    }
 public String getOldPwd() {
        return oldPwd;
    }

    public void setOldPwd(String oldPwd) {
        this.oldPwd = oldPwd;
    }

    public login getSessionData() {
        return sessionData;
    }

    public void setSessionData(login sessionData) {
        this.sessionData = sessionData;
    }

    public String[] getTagArray() {
        return tagArray;
    }

    public void setTagArray(String[] tagArray) {
        this.tagArray = tagArray;
    }

    public String getAns() {
        return ans;
    }

    public void setAns(String ans) {
        this.ans = ans;
    }

    public String getQ_id() {
        return q_id;
    }

    public void setQ_id(String q_id) {
        this.q_id = q_id;
    }

    public String getAtrName() {
        return atrName;
    }

    public void setAtrName(String atrName) {
        this.atrName = atrName;
    }

  

   
    
    public user()
    {
        
    }
    public user(String user, String pwd, String email,String tag,String role)
    {
        this.user=user;
        this.pwd=pwd;
        this.email=email;
        this.tag=tag;
        this.role=role;
    }
    public user(String user)
    {
        this.user=user;
    }
     public user(String user,  String email)
    {
        this.user=user;
        
        this.email=email;
    }
     public user(String user,String email, String tag)
     {
         this.user=user;
         this.email=email;
         this.tag=tag;
         
     }
    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getSec_qu1() {
        return sec_qu1;
    }

    public void setSec_qu1(String sec_qu1) {
        this.sec_qu1 = sec_qu1;
    }

    public String getSec_qu2() {
        return sec_qu2;
    }

    public void setSec_qu2(String sec_qu2) {
        this.sec_qu2 = sec_qu2;
    }

    public String getSec_ans1() {
        return sec_ans1;
    }

    public void setSec_ans1(String sec_ans1) {
        this.sec_ans1 = sec_ans1;
    }

    public String getSec_ans2() {
        return sec_ans2;
    }

    public void setSec_ans2(String sec_ans2) {
        this.sec_ans2 = sec_ans2;
    }
    
    
    
    public void welcome()
    {
        
    }

     public String postReview(String atrName, String atrReview)
    {
        try{            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            return "internalError";
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        String username=getSessionData().getId();
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            rs=stat.executeQuery("select * from t_attraction where attraction='"+atrName+"'");
            if(rs.next())
            {
                stat.executeUpdate("Insert into reviews values('"+username+"','"+atrName+"','"+atrReview+"')");
                return "reviewAdded";
            }
            else
            {
                return "attractionNotFound";
            }
            
        }
        catch(SQLException e)
        {
                    e.printStackTrace();
                    return ("Internal Error2");
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        
    }
     
    public String resetPassword()
    {
        boolean newPwdOk=false;
       
        if(newPwd1.equals(newPwd2))
        {
            newPwdOk=true;
        }
             
        if(!newPwdOk)
        {
            return "resetPwdError.xhtml";
        }
       
        else
        {
            try
            {           
             Class.forName("com.mysql.jdbc.Driver");
            }
            catch(Exception e)
            {
            return("Internal Error");
            }
            
            Connection conn=null;
            Statement stat=null;
            ResultSet rs=null;
            String username=getSessionData().getId();
            
            try{
                final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
                conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
                stat=conn.createStatement();
                rs=stat.executeQuery("select * from t_user where t_username='"+username+"'");
                boolean updated=false;
                if(rs.next())
                {
                    stat.executeUpdate("Update t_user set t_password='"+newPwd1+"' where t_username='"+username+"'");
                    updated=true;
                    
                }
                if(updated)
                {
                    return "resetPwdOk.xhtml";
                }
                else
                {
                    return "resetPwdError.xhtml";
                }
                
            }
            catch(SQLException e)
            {
                e.printStackTrace();
                return("Internal Error");
            }
            finally
            {
                try{
                    conn.close();
                    stat.close();
                    rs.close();
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                    return("Internal Error");
                }
            }
            
        }
        
    }
      public ArrayList<user> viewProfile()
    {
        try
            {           
             Class.forName("com.mysql.jdbc.Driver");
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            
            Connection conn=null;
            Statement stat=null;
            ResultSet rs=null;
            String username=getSessionData().getId();
            ArrayList<user> userDetails=new ArrayList<user>();
            try{
                final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
                conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
                stat=conn.createStatement();
                rs=stat.executeQuery("select * from t_user where t_username='"+username+"'");
                while(rs.next())
                {
                    userDetails.add(new user(username, rs.getString("t_email"),rs.getString("t_tag")));
                }
                
                }
            catch(SQLException e)
            {
                e.printStackTrace();
              
            }
            finally
            {
                try{
                    conn.close();
                    stat.close();
                    rs.close();
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                   
                }
            }
            return userDetails;
    }
    
    public String updateEmail()
    {
        try
            {           
             Class.forName("com.mysql.jdbc.Driver");
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return "internalError";
            }
            
            Connection conn=null;
            Statement stat=null;
            ResultSet rs=null;
            String username=getSessionData().getId();
           
            try{
                final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
                conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
                stat=conn.createStatement();
                rs=stat.executeQuery("select * from t_user where t_username='"+username+"'");
                boolean emailUpdated=false;
                    if(rs.next())
                    {
                    stat.executeUpdate("Update t_user set t_email='"+email+"' where t_username='"+username+"'");
                    emailUpdated=true;
                    return "emailUpdated";
                    }
                    
                        return "emailNotUpdated";
                    
                    
                 }
            catch(SQLException e)
            {
                e.printStackTrace();
              return "internalError";
            }
            finally
            {
                try{
                    conn.close();
                    stat.close();
                    rs.close();
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                   
                }
            }
            
    }
    
    public String updateTags()
    {
        try
            {           
             Class.forName("com.mysql.jdbc.Driver");
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return "internalError";
            }
            
            Connection conn=null;
            Statement stat=null;
            ResultSet rs=null;
            String username=getSessionData().getId();
           
            try{
                final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
                conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
                stat=conn.createStatement();
                rs=stat.executeQuery("select * from t_user where t_username='"+username+"'");
                boolean tagsUpdated=false;
                String tags="";
                for(String a:tagArray)
                {
                    tags+=a+", ";
                }
                    if(rs.next())
                    {
                    stat.executeUpdate("Update t_user set t_tag='"+tags+"' where t_username='"+username+"'");
                    tagsUpdated=true;
                    return "tagsUpdated";
                    }
                    
                        return "tagsNotUpdated";
                    
                    
                 }
            catch(SQLException e)
            {
                e.printStackTrace();
              return "internalError";
            }
            finally
            {
                try{
                    conn.close();
                    stat.close();
                    rs.close();
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                   
                }
            }
    }
    
      public ArrayList<question> displayQuestion()
    {
         try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        ArrayList<question> displayQuestion=new ArrayList<question>();
         final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
        
        
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
            String username=getSessionData().getId();
            rs=stat.executeQuery("select * from question_answer where q_user_id not like '"+username+"' and status not like '"+"read"+"'");
               //store all questions for the attraction in an arraylist
               
               while(rs.next())
               {
                   displayQuestion.add(new question(rs.getString(1),rs.getString(4),rs.getString(3),rs.getString(2)));
               }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        return displayQuestion;
    }
    
    public String answerQuestions()
    {
        try{            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            return "internalError";
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        String username=getSessionData().getId();
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            
               
                ans+=".By user: "+username+"#";
                 stat.executeUpdate("Update question_answer set answer='"+ans+"', status='"+"not read"+"' where question_id like '"+q_id+"'");
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try{
                conn.close();
                stat.close();
               rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
      return "Thank you for your answer";
}
    
    
    public String checkNotifications()
    {
        try{            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            return "internalError";
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        String username=getSessionData().getId();
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            rs=stat.executeQuery("select * from question_answer where q_user_id='"+username+"' and status='"+"not read"+"'");
            if(rs.next())
            {
                return "notificationFound";
            }
            return "";
        }
        catch(SQLException e)
        {
            
          e.printStackTrace();   
        }
        finally
        {
             //close the database
             try
             {
                 rs.close();
                 stat.close();
                 conn.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }
          return "notifications.xhtml"; 

    }
    public ArrayList<answers> displayNotifications()
    {
       try{            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
          //  return "internalError";
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        String username=getSessionData().getId();
        ArrayList<answers> ansList=new ArrayList<answers>();
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            //get all the user questions and answers into the result set
            //System.out.println(user_ID);
            rs=stat.executeQuery("select * from question_answer where q_user_id like '"+username+"' and status like '"+"not read"+"'");
            
            while(rs.next())
            {
                ansList.add(new answers(rs.getString("question"),rs.getString("answer"),rs.getString("answered_by"),rs.getString("attraction_name")));
            }
        }
        catch(SQLException e)
        {
            
          e.printStackTrace();   
        }
        finally
        {
             //close the database
             try
             {
                 rs.close();
                 stat.close();
                 conn.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }
        return ansList;
    }
    public void afterNotificationsCheck()
    {
        try{            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
          //  return "internalError";
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        String username=getSessionData().getId();
      
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            stat.executeUpdate("Update question_answer set status='read' where q_user_id='"+username+"'");
            }
        catch(SQLException e)
        {
            
          e.printStackTrace();   
        }
        finally
        {
             //close the database
             try
             {
                 rs.close();
                 stat.close();
                 conn.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }
    }
            
    
     public String addScore(String atrName, Double atrScore)
    {
         try{            
             Class.forName("com.mysql.jdbc.Driver");

        }catch(Exception e)
        {
            return "internalError";
        }
        Connection conn=null;
        Statement stat=null;
        ResultSet rs=null;
        String username=getSessionData().getId();
        final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try{
            
            conn=DriverManager.getConnection(db_url,"gurralar9537","1640227");
            stat=conn.createStatement();
            
            //check whether the attraction to post review is found in the attractions table
            rs=stat.executeQuery("select * from t_attraction");
            
            boolean attractionFound=false;
           while(rs.next())
            {
                if((rs.getString(2).toLowerCase()).equals(atrName.toLowerCase()))
                {
                    attractionFound=true;
                    break;
                }
            }
            if(!attractionFound )
            {
                return "The attraction is not found!";
                
            }
            if(attractionFound)
            {
//                 boolean validScore=false;
//                do{
//                
//              // int num= Integer.parseInt(atrScore);
//                int c=1;
//               
//                while(c<=5)
//                {
//                    if(atrScore==c)
//                    {
//                        validScore=true;
//                        break;
//                    }
//                    c++;
//                }
                int r=stat.executeUpdate("Insert into scores values('"+username+"','"+atrName+"','"+atrScore+"')");
                 
                    ResultSet av= stat.executeQuery("select avg(score) avg_score from scores where attraction_name='"+atrName+"'");
                   double avg=0;
                   while(av.next())
                   {
                       avg=av.getDouble("avg_score");
                   }
                    
                   stat.executeUpdate("Update t_attraction set score='"+avg+"' where attraction='"+atrName+"'");
                  return("Thank you for the rating");
 
                
                }else
                {
                    return ("The Score entered is not valid");
                }
            }
         
        catch(SQLException e)
        {
                    e.printStackTrace();
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return "Thank you for the score";
    }
    
     public ArrayList<youMayLike> displayYouMayLike()
    {
        try
        {
              Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        String tag1=getSessionData().getUserAccount().getTag();
        ArrayList<youMayLike> displayYouMayLike1 =new ArrayList<youMayLike>();
        final String DATABASE_URL = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        Connection conn = null;  //a connection to the database
        Statement stat = null;    //execution of a statement
        ResultSet rs = null;   //set of results
               
        try
        {      
            //connect to the database with user name and password
            conn = DriverManager.getConnection(DATABASE_URL, 
                    "gurralar9537", "1640227");   
            stat = conn.createStatement();
                        
//         List<String>tagItem=Arrays.asList(tag1.split("#"));
//         List<attraction>attr=new ArrayList<>();
//         Map<String,attraction> uniqueAttractions=new HashMap();
//         attraction a=null;
//            //rs=stat.executeQuery("select attraction_id, attraction_name from attractions where tag=aTag group by tag order by Score desc");
//            for(String t: tagItem)
//            {
//                rs=stat.executeQuery("Select * from t_attraction where tag like '"+t+"' order by Score desc limit 3");
//                while(rs.next())
//                {
//                a=new attraction(rs.getString("attr_id"),rs.getString("attraction"),rs.getString("city"),rs.getDouble("score"));
//                attr.add(a);
//                String att_Name=rs.getString(2);
//                uniqueAttractions.put(att_Name,a);
//                }
//            }
//            
//            attr=new ArrayList<>(uniqueAttractions.values());
//            attr.sort(Comparator.comparingDouble(attraction::getScore));
//            int i=0;
//            for(attraction aL:attr)
//            {
////                return aL;
//            }
            
            rs=stat.executeQuery("Select * from t_attraction where tag like '"+tag1+"' order by Score desc limit 3");
            
            while(rs.next())
            {
             // displayYouMayLike1.add(new attraction(rs.getString(1),rs.getString(2),rs.getString(5),rs.getDouble(9)));
            displayYouMayLike1.add(new youMayLike(rs.getString("attr_id"),rs.getString("attraction"),rs.getString("city"),rs.getDouble("score")));
            }            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            
        }
        finally
        {
            try{
                conn.close();
                stat.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();    
            }
        }
        return displayYouMayLike1;
    }
     public ArrayList<question> displayAttr()
     {
         try {
            Class.forName("com.mysql.jdbc.Driver");

        } catch (Exception e) {
            e.printStackTrace();
        }
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        String username=getSessionData().getId();
        ArrayList<question> displayAttr = new ArrayList<question>();
        final String db_url = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try {
            //coonection to the database
            conn = DriverManager.getConnection(db_url, "gurralar9537", "1640227");
            //Create a statement
            stat = conn.createStatement();
            rs = stat.executeQuery("select * from t_attraction");
            while(rs.next())
            {
                displayAttr.add(new question(rs.getString("attr_id"), rs.getString("attraction")));
            }
        
    }catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
                stat.close();
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return displayAttr;
     }
     public String askQuestions(String atrID, String quest) {
        try {
            Class.forName("com.mysql.jdbc.Driver");

        } catch (Exception e) {
            return "internalError";
        }
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        String username=getSessionData().getId();
        final String db_url = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try {
            //coonection to the database
            conn = DriverManager.getConnection(db_url, "gurralar9537", "1640227");
            //Create a statement
            stat = conn.createStatement();
//            rs = stat.executeQuery("select * from attraction");
            String a_name = "";
//            ArrayList<question> atrList = new
//            while (rs.next()) {
//                atrList.add(new question(rs.getString(1), rs.getString(2)));
//
//            }
            boolean attractionFound = false;
            rs = stat.executeQuery("select * from t_attraction");

            while (rs.next()) {
                if (atrID.equals(rs.getString(1))) {
                    attractionFound = true;
                    a_name = rs.getString(2);
                }
            }
//            if (attractionFound) {
                rs = stat.executeQuery("select * from t_user");
                boolean userFound = false;
                while (rs.next()) {
                    if (rs.getString(2).toLowerCase().equals(username.toLowerCase())) {
                        userFound = true;
                        break;
                    }
                }
                if (userFound) {
                    //get next question id
                    int next = 0;
                    rs = stat.executeQuery("select * from next_question_id");
                    while (rs.next()) {
                        next = rs.getInt(1);
                        next += 1;
                    }
                    String q_id = "Q" + next;
                    stat.executeUpdate("Update next_question_id set next = '" + next + "'");
                    question user_question = new question(q_id, quest, a_name, username);
                    //user_question.addQuestion();
                    //int t = stat.executeUpdate("insert into ")
                     stat.executeUpdate("Insert into question_answer values('"+q_id+"','"+username+"','"+a_name+"','"+quest+"','"+" "+"','"+" "+"')");
                } else if (!userFound) {
                    return "User not found";

                }
//            } else {
//                return "Enter a valid attraction ID";
//            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
                stat.close();
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return "Thank you for posting this question";
    }
     
      public String attract()
    {
        
      attractions attr =  new attractions(user);
      login log = new login();
        return "createAttraction";
    }
     public String fav_atr_page(String att)
    {
        atrName=att;
        return "favouriteAttraction";
    }
      
      public ArrayList<attractions> displayFavoriteAttractions()
      {
           try {
            Class.forName("com.mysql.jdbc.Driver");

        } catch (Exception e) {
            e.printStackTrace();
        }
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        String username=getSessionData().getId();
        ArrayList<attractions> displayAttr = new ArrayList<attractions>();
        final String db_url = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try {
            //coonection to the database
            conn = DriverManager.getConnection(db_url, "gurralar9537", "1640227");
            //Create a statement
            stat = conn.createStatement();
            rs = stat.executeQuery("select * from fav_attraction where user_id='"+username+"'");
            while(rs.next())
            {
                displayAttr.add(new attractions(rs.getString("attraction_name")));
            }
        
            }catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
                stat.close();
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return displayAttr;
      }
      
       public ArrayList<attractions> displayFavoriteDestinations()
      {
           try {
            Class.forName("com.mysql.jdbc.Driver");

        } catch (Exception e) {
            e.printStackTrace();
        }
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        String username=getSessionData().getId();
        ArrayList<attractions> displayCity = new ArrayList<attractions>();
        final String db_url = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try {
            //coonection to the database
            conn = DriverManager.getConnection(db_url, "gurralar9537", "1640227");
            //Create a statement
            stat = conn.createStatement();
            rs = stat.executeQuery("select * from fav_city where user_id='"+username+"'");
            while(rs.next())
            {
                displayCity.add(new attractions(rs.getString("fav_city")));
            }
        
            }catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
                stat.close();
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return displayCity;
      }
       
       public String addFavoriteAttracton(String attr)
       {
           try {
            Class.forName("com.mysql.jdbc.Driver");

        } catch (Exception e) {
            e.printStackTrace();
            return "internalError";
        }
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        String username=getSessionData().getId();
  
        final String db_url = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try {
            //coonection to the database
            conn = DriverManager.getConnection(db_url, "gurralar9537", "1640227");
            //Create a statement
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from fav_attraction where user_id='"+username+"'");
            boolean attFound=false;
            while(rs.next())
            {
                if(rs.getString("attraction_name").equals(attr))
                {
                    attFound=true;
                }
            }
            if(!attFound)
            {
                stat.executeUpdate("Insert into fav_attraction values('"+username+"','"+attr+"')");
                return "favAttAdded";
            }
            else
            {
                return "favAttExists";
            }
            
            }catch (SQLException e) {
            e.printStackTrace();
            return "internalError";
        } finally {
            try {
                conn.close();
                stat.close();
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
               
            }
        }
       }
       
        public String addFavoriteCity(String fav_city)
       {
           try {
            Class.forName("com.mysql.jdbc.Driver");

        } catch (Exception e) {
            e.printStackTrace();
            return "internalError";
        }
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        String username=getSessionData().getId();
  
        final String db_url = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try {
            //coonection to the database
            conn = DriverManager.getConnection(db_url, "gurralar9537", "1640227");
            //Create a statement
            stat = conn.createStatement();
            rs=stat.executeQuery("select * from fav_city where user_id='"+username+"'");
            boolean cityFound=false;
            while(rs.next())
            {
                if(rs.getString("fav_city").equals(fav_city))
                {
                    cityFound=true;
                }
            }
            if(!cityFound)
            {
                stat.executeUpdate("Insert into fav_city values('"+username+"','"+fav_city+"')");
                return "favAttAdded";
            }
            else
            {
                return "favAttExists";
            }
            
            }catch (SQLException e) {
            e.printStackTrace();
            return "internalError";
        } finally {
            try {
                conn.close();
                stat.close();
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
               
            }
        }
       }
}
