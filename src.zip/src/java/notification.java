/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author 123456
 */
@ManagedBean
@SessionScoped
public class notification {

    /**
     * Creates a new instance of notification
     */
    public notification() {
    }
    
//    public void checkNotifications()
//    {
//        
//         Connection conn=null;
//        Statement stat=null;
//        ResultSet rs=null;
//        Scanner input =new Scanner(System.in);
//        
//        try{
//            final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
//            //coonection to the database
//            conn=DriverManager.getConnection(db_url, "gurralar9537", "1640227");
//            //Create a statement
//            stat=conn.createStatement();
//            //get all the user questions and answers into the result set
//            System.out.println(user_ID);
//            rs=stat.executeQuery("select * from question_answer where q_user_id like '"+user_ID+"' and status like '"+"not read"+"'");
//            //check whether the user is found in the resultset
//            boolean userFound=false;
//            String attraction="";
//            String seeNotifications="";
//            //create an array list to store answers
//            ArrayList<answers> ans=new ArrayList<answers>();
//            while(rs.next())
//            {
//                
//                userFound=true;
//                
//                attraction+=rs.getString(3)+", ";
//                ans.add(new answers(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4), rs.getString(5)));
//            }
//            System.out.println("Notification:");
//                System.out.println("Your questions on  "+attraction+" are answered");
//            
//                if(userFound)
//            {
//                
//                for(answers a:ans)
//                {
//                
//                System.out.println("Please click '1' to see the answers");
//                seeNotifications=input.nextLine();
//
//                    if(seeNotifications.equals("1"))
//                    {
//                         //rs=stat.executeQuery("select * from question_answer where q_user_id like '"+user_ID+"' and status like'"+"not read"+"'");
//                       // while(rs.next())
//                        //    userFound=true;
//                            System.out.println("Answers for ur questions on "+a.getAttraction()+"are: ");
//                            System.out.println("Your question: ");
//                             System.out.println(a.getQuestion());
//                            //System.out.println("Please choose ur option: ");
//                                                String[] answers=a.getAnswer().split("#");
//                            for(int i=0;i<answers.length;i++)
//                            {
//                                System.out.println(answers[i]);
//                            }
//
//                            stat.executeUpdate("Update question_answer set status='"+"read"+"' where question_id like '"+a.getQuestion_id()+"'");
//
//
//                        //}
//
//                    }
//                }
//            }
//        }
//        catch(SQLException e)
//        {
//            
//          e.printStackTrace();   
//        }
//        finally
//        {
//             //close the database
//             try
//             {
//                 rs.close();
//                 stat.close();
//                 conn.close();
//             }
//             catch(Exception e)
//             {
//                 e.printStackTrace();
//             }
//        }
//
//    }
//    
//    public boolean notificationFound()
//    {
//        Connection conn=null;
//        Statement stat=null;
//        ResultSet rs=null;
//        Scanner input =new Scanner(System.in);
//        
//        try{
//            final String db_url="jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
//            //coonection to the database
//            conn=DriverManager.getConnection(db_url, "gurralar9537", "1640227");
//            //Create a statement
//            stat=conn.createStatement();
//            //get all the user questions and answers into the result set
//            //System.out.println(user_ID);
//            rs=stat.executeQuery("select * from question_answer where q_user_id like '"+user_ID+"' and status like '"+"not read"+"'");
//            
//            while(rs.next())
//            {
//                return true;
//            }
//        }
//        catch(SQLException e)
//        {
//            
//          e.printStackTrace();   
//        }
//        finally
//        {
//             //close the database
//             try
//             {
//                 rs.close();
//                 stat.close();
//                 conn.close();
//             }
//             catch(Exception e)
//             {
//                 e.printStackTrace();
//             }
//        }
//        return false;
//    }
}
