/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;

/**
 *
 * @author 123456
 */
@ManagedBean
@Named(value = "youMayLike")
@SessionScoped
public class youMayLike implements Serializable {

    /**
     * Creates a new instance of youMayLike
     * 
     * 
     */
    
    private String attrName;
    private String attrID;

    public String getAttrName() {
        return attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public String getAttrID() {
        return attrID;
    }

    public void setAttrID(String attrID) {
        this.attrID = attrID;
    }

    public String getAttrcity() {
        return attrcity;
    }

    public void setAttrcity(String attrcity) {
        this.attrcity = attrcity;
    }

    public Double getAttrscore() {
        return attrscore;
    }

    public void setAttrscore(Double attrscore) {
        this.attrscore = attrscore;
    }
    private String attrcity;
    private Double attrscore;
    public youMayLike(String id, String atr_name, String atr_city, Double atr_score) {
        attrID = id;
        attrName = atr_name;
        attrcity = atr_city;
        attrscore = atr_score;
    }
    
 }

