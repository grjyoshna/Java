/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.inject.Named;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 * @author 123456
 */
@ManagedBean
@SessionScoped
@Named(value = "question")

public class question {
    
    public question()
    {
        
    }

    public login getSessionData() {
        return SessionData;
    }

    public void setSessionData(login SessionData) {
        this.SessionData = SessionData;
    }

   private login SessionData;
    private String question_id;
    private String question;
    private String attraction;
    private String user_ID;
    private String atrID2;
    
    private int q_id;
    private String ans;
    
    
    
    public int getQ_id() {
        return q_id;
    }

    public void setQ_id(int q_id) {
        this.q_id = q_id;
    }

    public String getAns() {
        return ans;
    }

    public void setAns(String ans) {
        this.ans = ans;
    }

    public String getAtrID2() {
        return atrID2;
    }

    public void setAtrID2(String atrID2) {
        this.atrID2 = atrID2;
    }

    public question(String question_id, String question, String attraction, String user_ID) {
        this.question_id = question_id;
        this.question = question;
        this.attraction = attraction;
        this.user_ID = user_ID;
    }

    public String atrName;
    public String atrID;

    public question(String aID, String aName) {
        this.atrID = aID;
        this.atrName = aName;
    }

    public String getAtrName() {
        return atrName;
    }

    public void setAtrName(String atrName) {
        this.atrName = atrName;
    }

    public String getAtrID() {
        return atrID;
    }

    public void setAtrID(String atrID) {
        this.atrID = atrID;
    }
    
     public void addQuestion()
    {
        try {

            Class.forName("com.mysql.jdbc.Driver");

        } catch (Exception e) {
            e.printStackTrace();
        }
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        String username = getSessionData().getId();
        final String db_url = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try {
            //coonection to the database
            conn = DriverManager.getConnection(db_url, "gurralar9537", "1640227");
            //Create a statement
            stat = conn.createStatement();
            
            //generate question id
            rs=stat.executeQuery("select * from next_question_id");
            int q_id=0;
            while(rs.next())
            {
                q_id=rs.getInt(1);
                q_id+=1;
            }
            String qu_id="Q"+q_id;
           
            stat.executeUpdate("Insert into question_answer values('"+qu_id+"','"+user_ID+"','"+attraction+"','"+question+"','"+" "+"','"+" "+"')");
            //return "your question has been posted successfully!";
            //System.out.println(" ");
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try{
                conn.close();
                stat.close();
               rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    public String askQuestions() {
        try {

            Class.forName("com.mysql.jdbc.Driver");

        } catch (Exception e) {
            return "internalError";
        }
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        String username = getSessionData().getId();
        final String db_url = "jdbc:mysql://mis-sql.uhcl.edu/gurralar9537";
        try {
            //coonection to the database
            conn = DriverManager.getConnection(db_url, "gurralar9537", "1640227");
            //Create a statement
            stat = conn.createStatement();
            rs = stat.executeQuery("select * from attraction");
            String a_name = "";

            while (rs.next()) {
               // atrList.add(new question(rs.getString(1), rs.getString(2)));

            }
            boolean attractionFound = false;
            rs = stat.executeQuery("select * from attraction");

            while (rs.next()) {
                if (atrID2.equals(rs.getString(1))) {
                    attractionFound = true;
                    a_name = rs.getString(2);
                }
            }
            if (attractionFound) {
                rs = stat.executeQuery("select * from user");
                boolean userFound = false;
                while (rs.next()) {
                    if (rs.getString(1).toLowerCase().equals(username.toLowerCase())) {
                        userFound = true;
                        break;
                    }
                }
                if (userFound) {
                    //get next question id
                    int next = 0;
                    rs = stat.executeQuery("select * from next_question_id");
                    while (rs.next()) {
                        next = rs.getInt(1);
                        next += 1;
                    }
                    String q_id = "Q" + next;
                    stat.executeUpdate("Update next_question_id set next = '" + next + "'");
                    question user_question = new question(q_id, question, a_name, username);
                    user_question.askQuestions();
                } else if (!userFound) {
                    return "User not found";

                }
            } else {
                return "Enter a valid attraction ID";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
                stat.close();
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return "Thank you for posting this question";
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAttraction() {
        return attraction;
    }

    public void setAttraction(String attraction) {
        this.attraction = attraction;
    }

    public String getUser_ID() {
        return user_ID;
    }

    public void setUser_ID(String user_ID) {
        this.user_ID = user_ID;
    }

    public String getQuestion_id() {
        return question_id;
    }

    public void setQuestion_id(String question_id) {
        this.question_id = question_id;
    }
}
